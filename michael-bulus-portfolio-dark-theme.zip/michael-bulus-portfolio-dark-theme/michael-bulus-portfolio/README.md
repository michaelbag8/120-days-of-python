# Michael Bulus Gambo — Portfolio

A lightweight, responsive personal portfolio inspired by the text-first, editorial feel of Kenneth Reitz's website. It is an original implementation with your own name, profile, and project descriptions, not a copy of his source code or content.

## Run locally

No build tools or package installation are required.

1. Extract the ZIP.
2. Open `index.html` in your browser.

For a local development server, open a terminal in this folder and run:

```bash
python3 -m http.server 8000
```

Then visit <http://localhost:8000>.

## Deploy

### GitHub Pages
1. Create a GitHub repository, for example `michael-bulus-portfolio`.
2. Upload the files in this folder to the repository root.
3. In GitHub, open **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. GitHub will provide your public website URL.

### Netlify
Drag the extracted project folder into Netlify's manual deploy area, or connect the GitHub repository. No build command is needed; publish directory is `.`.

## Personalize before publishing

- Confirm project links point to the correct repositories.
- Replace the placeholder email `hello@michaelbulus.dev` with an email address you use.
- Add links to published articles when available.
- Keep project descriptions accurate and update the page as your work progresses.

## Files

- `index.html` — page content and structure
- `styles.css` — typography, spacing, colors, responsive layout
- `script.js` — automatically updates the copyright year
